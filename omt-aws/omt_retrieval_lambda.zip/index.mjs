import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);


export const handler = async (event) => {
  
  const command = new ScanCommand({
    TableName: process.env.TABLE_NAME,
  });

  const db_response = await docClient.send(command);

  const response = {
    statusCode: 200,
    body: JSON.stringify(db_response["Items"]),
  };
  return response;
};
